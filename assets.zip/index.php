<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
        <link rel="stylesheet" href="assets/css/styles.css">
        <title>haloana.com</title>
    </head>
    <body>

        <main class="l-main">
            <section class="menu section bd-container" id="menu">
                <form id="imgForm" action="./3d/examples/open.php" method="POST">
                <!-- <form id="imgForm" action="./proses.php" method="POST"> -->
                    <input type="hidden" name="gambar" id="gambarInput">
                </form>
                <div class="menu__container bd-grid" id="content"></div>
            </section>
        </main>

        <?php
        function sapa() {
            $host   = 'localhost:3306';
            $dbname = 'halx6938_postgres';
            $user   = 'halx6938';
            $pass   = 'YG3Gp9UBnJwb28';
            try {
                $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                // echo "Koneksi berhasil dengan PDO!";
                $sql = "SELECT * FROM users ORDER BY RAND() LIMIT 16";
                $stmt = $pdo->query($sql);
                $GLOBALS['json'] = json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
            } catch (PDOException $e) {
                // echo "Koneksi gagal: " . $e->getMessage();
            }
        }
        sapa();
        ?>

        <script>
          const content = document.getElementById("content");

        function createCard(title,hargaS,linkS) {
            // Buat elemen utama card
            const card = document.createElement("div");
            card.className = "menu__content";

            // Buat elemen judul
            const cardTitle = document.createElement("h3");
            cardTitle.className = "menu__name";
            cardTitle.textContent = title;

            const img = document.createElement("img");

            // Atur atribut gambar
            img.src         = `assets/img/`+title+`.png`;
            img.className   = "menu__img";
            img.addEventListener("click", function() {
            submitGambar('assets/img/'+title+'.png');
            });

            // Buat elemen isi
            const cardContentHarga = document.createElement("span");
            cardContentHarga.className = "menu__preci";
            cardContentHarga.textContent = `Rp `+hargaS;

            const link = document.createElement("a");

            // Atur atribut
            link.href = linkS;
            link.textContent = "Shopee.com";
            link.target = "_blank"; 
            link.style.textDecoration = "none";
            link.style.color = "blue";

            // Gabungkan elemen
            card.appendChild(img);
            card.appendChild(cardTitle);
            // card.appendChild(cardContent);
            card.appendChild(cardContentHarga);
            card.appendChild(link);


            // Tambahkan ke container
            document.getElementById("content").appendChild(card);
          }


          function submitGambar(namaGambar) {
            document.getElementById('gambarInput').value = namaGambar;
            document.getElementById('imgForm').submit();
          }

          function loadMoreItems() {
            let dataL = <?php sapa(); echo $GLOBALS['json']; ?> ;
            dataL.forEach((person, index) => {
              // console.log(`Person ${index + 1}:`);
              createCard(`${person.name}`,`${person.harga}`,`${person.link}`);
            });
          }

          // Initial load
          loadMoreItems();

          window.addEventListener("scroll", () => {
            // Check if user is near bottom of the page
            if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 50) {
              loadMoreItems();
            }
          });
        </script>

</body>
</html>
    </body>
</html>