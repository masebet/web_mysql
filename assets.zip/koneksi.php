<?php 
try {
	$host = 'localhost';
	$port = '';
	$dbname = 'arindana';
	$user = 'postgres';
	$password = '';

	$pdo = new PDO("pgsql:host=$host;$post;dbname", $user, $password);
	$pdo ->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	echo "Koneksi Berhasil";
}catch (PDOException $e){
	echo "koneksi gagal" . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
        <link rel="stylesheet" href="assets/css/styles.css">
        <title>Responsive website food</title>
    </head>
    <body>

        <main class="l-main">
            <!--========== MENU ==========-->
            <section class="menu section bd-container" id="menu">
                <div class="menu__container bd-grid">
                    
                    <div class="menu__content">
                        <img src="assets/img/plate1.png" alt="" class="menu__img">
                        <h3 class="menu__name">CELANA</h3>
                        <span class="menu__detail">TOKOPEDIA</span>
                        <span class="menu__preci">Rp 20000.00</span>
                        <a href="#" class="button menu__button"><i class='bx bx-cart-alt'></i></a>
                    </div>

                </div>
            </section>
        </main>

        <?php
            echo "hallo";
            echo "\nini echo";
        ?>
        <script src="https://unpkg.com/scrollreveal"></script>
        <script src="assets/js/main.js"></script>
    </body>
</html>