<?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $gambar = $_POST['gambar'] ?? 'tidak ada';
        echo "<h2>Gambar yang dipilih:</h2>";
        echo "<p>Nama file: $gambar</p>";
        echo "<img src='$gambar' alt='Gambar yang dipilih' width='300'>";
    } else {
        echo "Akses tidak valid.";
    }
?>
