<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
        <link rel="stylesheet" href="assets/css/styles.css">
        <title>Responsive website food</title>
    </head>
    <body>
        <?php
            $host   = 'localhost:3306';
            $dbname = 'halx6938_postgres';
            $user   = 'halx6938';
            $pass   = 'YG3Gp9UBnJwb28';

        try {
            $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            echo "Koneksi berhasil dengan PDO!";

        //=================== Buka file CSV
        if (($handle = fopen("data.csv", "r")) !== false) {
            $isHeader = true;

            while (($data = fgetcsv($handle, 1000, ",")) !== false) {
                if ($isHeader) {
                    $isHeader = false; // skip header row
                    continue;
                }

                $name  = $data[0];
                $link  = $data[1];
                $harga = $data[2];
                $diskon = $data[3];

                $sql = "INSERT INTO users (name, link,harga, diskon) VALUES (:name, :link,:harga, :diskon)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    ':name'  => $name,
                    ':link'  => $link,
                    ':harga' => $harga,
                    ':diskon'=> $diskon

                ]);
            }

            fclose($handle);
            echo "Import selesai.";
        } else {
            echo "Gagal membuka file CSV.";
        }//==================================

        } catch (PDOException $e) {
            echo "Koneksi gagal: " . $e->getMessage();
        }

        ?>
    </body>
</html>